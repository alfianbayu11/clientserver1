nilai = 10

if nilai >= 0 :
    print("Nilai bernilai Positif")