fruits = ("apple", "banana", "cherry")

for fruit in fruits:
    print(fruit)
print("-----------------------\n")
