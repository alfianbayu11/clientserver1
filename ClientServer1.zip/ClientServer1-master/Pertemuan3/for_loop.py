fruits = ["apple", "banana", "chery"]

for x in fruits:
    print(x)
